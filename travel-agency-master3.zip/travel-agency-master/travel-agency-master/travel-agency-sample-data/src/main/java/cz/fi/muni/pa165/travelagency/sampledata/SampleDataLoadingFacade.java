package cz.fi.muni.pa165.travelagency.sampledata;

import java.io.IOException;

/**
 *
 * @author Michal Holic
 */
public interface SampleDataLoadingFacade {
    void loadData() throws IOException;
}
