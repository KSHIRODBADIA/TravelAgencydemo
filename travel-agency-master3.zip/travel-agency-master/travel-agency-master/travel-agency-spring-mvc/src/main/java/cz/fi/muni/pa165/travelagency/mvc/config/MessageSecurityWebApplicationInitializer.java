package cz.fi.muni.pa165.travelagency.mvc.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 *
 * @author Michal Holic
 */
public class MessageSecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {
    
}
