package cz.fi.muni.pa165.travelagency.service.facade;

import cz.fi.muni.pa165.travelagency.facade.AdministratorFacade;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author 
 */
@Service
@Transactional
public class AdministratorFacadeImpl extends UserFacadeImpl implements AdministratorFacade {
    
}
